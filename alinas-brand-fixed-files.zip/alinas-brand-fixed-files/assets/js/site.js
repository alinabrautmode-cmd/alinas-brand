/* ============================================================
   ALINA'S BRAND — fixed site script
   Fixes:
   - search works for AB692, AB-692, 692, AB680/1, AB-680/1
   - mobile catalog loads fewer images to avoid Safari crash/reload
   - safer hash scrolling for article IDs with symbols like /
   - safer mobile menu / fade-in for older mobile browsers
============================================================ */
(function () {
  'use strict';

  var WHATSAPP_URL = 'https://wa.me/380936652455';

  function forEachNode(list, callback) {
    Array.prototype.forEach.call(list || [], callback);
  }

  function escapeHtml(value) {
    return String(value == null ? '' : value).replace(/[&<>"']/g, function (char) {
      return {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#39;'
      }[char];
    });
  }

  function escapeAttr(value) {
    return escapeHtml(value);
  }

  function listText(value) {
    return Array.isArray(value) && value.length ? value.join(', ') : '—';
  }

  function cssUrl(value) {
    return 'url("' + String(value || '').replace(/\\/g, '\\\\').replace(/"/g, '\\"') + '")';
  }

  function normalizeArticle(value) {
    var v = String(value || '').toUpperCase().trim();
    v = v.replace(/\s+/g, '');
    v = v.replace(/^ART\.?/i, '');
    v = v.replace(/^AB-/, 'AB');
    if (/^\d/.test(v)) v = 'AB' + v;
    return v;
  }

  function articleMatches(productArticle, searchValue) {
    var a = normalizeArticle(productArticle);
    var q = normalizeArticle(searchValue);
    if (!q || q === 'AB') return false;
    if (a === q) return true;
    // Allow searching only by numbers, for example 692 or 680/1
    var aNoPrefix = a.replace(/^AB/, '');
    var qNoPrefix = q.replace(/^AB/, '');
    return aNoPrefix === qNoPrefix;
  }

  function getCategoryUrl(category) {
    var map = {
      dresses: '/catalog-dresses.html',
      suits: '/catalog-suits.html',
      jumpsuits: '/catalog-jumpsuits.html'
    };
    return map[category] || '/catalog-dresses.html';
  }

  function initFadeIn() {
    var items = document.querySelectorAll('.fade-in');
    if (!items.length) return;

    if (!('IntersectionObserver' in window)) {
      forEachNode(items, function (el) { el.classList.add('visible'); });
      return;
    }

    var obs = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          obs.unobserve(entry.target);
        }
      });
    }, { threshold: 0.08 });

    forEachNode(items, function (el) { obs.observe(el); });
  }

  function initMobileNav() {
    var hamburger = document.querySelector('.hamburger');
    var mobileNav = document.querySelector('.mobile-nav');
    if (!hamburger || !mobileNav) return;

    hamburger.addEventListener('click', function () {
      mobileNav.classList.toggle('active');
      document.body.classList.toggle('nav-open');
    });

    forEachNode(mobileNav.querySelectorAll('a'), function (link) {
      link.addEventListener('click', function () {
        mobileNav.classList.remove('active');
        document.body.classList.remove('nav-open');
      });
    });
  }

  function initHomeContent() {
    var home = window.ALINAS_BRAND_HOME;
    if (!home) return;

    var hero = home.hero || {};
    var heroBg = document.querySelector('[data-home-hero-image]');
    if (heroBg && hero.image) {
      heroBg.style.backgroundImage = cssUrl(hero.image);
      heroBg.style.setProperty('--hero-image-desktop', cssUrl(hero.image));
    }
    if (heroBg && hero.mobileImage) heroBg.style.setProperty('--hero-image-mobile', cssUrl(hero.mobileImage));
    if (heroBg && hero.imagePosition) heroBg.style.backgroundPosition = hero.imagePosition;

    var map = {
      '[data-home-hero-overtitle]': hero.overtitle,
      '[data-home-hero-title]': hero.title,
      '[data-home-hero-subtitle]': hero.subtitle,
      '[data-home-hero-kicker]': hero.kicker
    };

    Object.keys(map).forEach(function (selector) {
      var el = document.querySelector(selector);
      if (el && map[selector]) el.textContent = map[selector];
    });

    var heroButton = document.querySelector('[data-home-hero-button]');
    if (heroButton) {
      if (hero.buttonText) heroButton.textContent = hero.buttonText;
      if (hero.buttonUrl) heroButton.setAttribute('href', hero.buttonUrl);
    }

    var categories = home.categories || {};
    Object.keys(categories).forEach(function (key) {
      var data = categories[key] || {};
      var card = document.querySelector('[data-home-category="' + key + '"]');
      if (!card) return;
      var image = card.querySelector('[data-home-category-image]');
      var title = card.querySelector('[data-home-category-title]');
      var subtitle = card.querySelector('[data-home-category-subtitle]');
      if (data.url) card.setAttribute('href', data.url);
      if (image && data.image) image.setAttribute('src', data.image);
      if (image && data.title) image.setAttribute('alt', data.title);
      if (title && data.title) title.textContent = data.title;
      if (subtitle && data.subtitle) subtitle.textContent = data.subtitle;
    });
  }

  function initProductGallery() {
    forEachNode(document.querySelectorAll('[data-product-gallery]'), function (gallery) {
      var mainImage = gallery.querySelector('[data-product-main-image]');
      var thumbs = gallery.querySelectorAll('[data-product-thumb]');
      if (!mainImage || !thumbs.length) return;

      forEachNode(thumbs, function (button) {
        button.addEventListener('click', function () {
          var nextImage = button.getAttribute('data-image');
          var nextAlt = button.getAttribute('data-alt') || mainImage.alt;
          if (!nextImage) return;
          mainImage.src = nextImage;
          mainImage.alt = nextAlt;
          forEachNode(thumbs, function (item) { item.classList.remove('is-active'); });
          button.classList.add('is-active');
        });
      });
    });
  }

  function initSearch() {
    var toggle = document.querySelector('.search-toggle');
    var panel = document.querySelector('.search-panel');
    if (!toggle || !panel) return;

    var input = panel.querySelector('.search-input');
    var feedback = panel.querySelector('.search-feedback');
    var closeBtn = panel.querySelector('.search-close');
    if (!input) return;

    function openPanel() {
      panel.classList.add('is-open');
      toggle.setAttribute('aria-expanded', 'true');
      setTimeout(function () { input.focus(); }, 60);
    }

    function closePanel() {
      panel.classList.remove('is-open');
      toggle.setAttribute('aria-expanded', 'false');
      if (feedback) feedback.textContent = '';
      input.value = '';
    }

    toggle.addEventListener('click', function (e) {
      e.preventDefault();
      panel.classList.contains('is-open') ? closePanel() : openPanel();
    });

    if (closeBtn) closeBtn.addEventListener('click', closePanel);

    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && panel.classList.contains('is-open')) closePanel();
    });

    panel.addEventListener('submit', function (e) {
      e.preventDefault();
      runSearch();
    });

    function runSearch() {
      var raw = (input.value || '').trim();
      if (!raw) {
        if (feedback) feedback.textContent = 'Please enter an article number, for example AB692.';
        return;
      }

      var normalized = normalizeArticle(raw);
      if (!/^AB\d+(\/\d+)?$/.test(normalized)) {
        if (feedback) feedback.textContent = 'Article format is AB692, AB-692 or AB680/1.';
        return;
      }

      var products = window.ALINAS_BRAND_PRODUCTS || [];
      var match = null;
      for (var i = 0; i < products.length; i += 1) {
        if (articleMatches(products[i].article, raw)) {
          match = products[i];
          break;
        }
      }

      if (!match) {
        if (feedback) feedback.textContent = 'No product found for "' + raw + '".';
        return;
      }

      if (match.pageUrl) {
        window.location.href = match.pageUrl;
      } else {
        window.location.href = getCategoryUrl(match.category) + '#' + encodeURIComponent(normalizeArticle(match.article).toLowerCase());
      }
    }
  }

  function renderProductCard(p) {
    var articleId = normalizeArticle(p.article).toLowerCase();
    var productUrl = p.pageUrl ? escapeAttr(p.pageUrl) : '';
    var safeName = escapeHtml(p.name || p.article || 'Product');
    var safeArticle = escapeHtml(p.article || '');
    var safeTagline = escapeHtml(p.tagline || '');
    var safeDescription = escapeHtml(p.description || '');
    var safeColors = escapeHtml(listText(p.colors));
    var safeSizes = escapeHtml(listText(p.sizes));
    var safeAvailability = escapeHtml(p.availability || '');

    // Important mobile fix: do not inject every image from every product on the catalog page.
    // Mobile Safari can reload/crash when the page creates too many large images at once.
    var galleryImages = (p.images || []).filter(Boolean).slice(0, 3);
    if (!galleryImages.length) galleryImages = [''];

    var galleryHtml = galleryImages.map(function (src, idx) {
      var safeSrc = escapeAttr(src);
      var alt = safeName + ' image ' + (idx + 1);
      var img = safeSrc
        ? '<img src="' + safeSrc + '" alt="' + escapeAttr(alt) + '" loading="lazy" decoding="async">'
        : '<div class="catalog-model__placeholder">No image</div>';

      if (productUrl) {
        return '<a class="catalog-model__frame" href="' + productUrl + '">' + img + '</a>';
      }
      return '<div class="catalog-model__frame">' + img + '</div>';
    }).join('');

    var ctaHtml = productUrl
      ? '<a class="catalog-model__cta" href="' + productUrl + '">View product</a>'
      : '<a class="catalog-model__cta" href="' + WHATSAPP_URL + '" target="_blank" rel="noopener">Enquire on WhatsApp</a>';

    return '' +
      '<article class="catalog-model fade-in" id="' + escapeAttr(articleId) + '">' +
        '<div class="catalog-model__gallery">' + galleryHtml + '</div>' +
        '<div class="catalog-model__caption">' +
          '<div class="catalog-model__article">Art. ' + safeArticle + '</div>' +
          (safeTagline ? '<div class="catalog-model__tagline">' + safeTagline + '</div>' : '') +
          (safeDescription ? '<p class="catalog-model__description">' + safeDescription + '</p>' : '') +
          '<div class="catalog-model__meta">Available colors: ' + safeColors + '</div>' +
          '<div class="catalog-model__meta">Available sizes: ' + safeSizes + '</div>' +
          (safeAvailability ? '<div class="catalog-model__meta">' + safeAvailability + '</div>' : '') +
          ctaHtml +
        '</div>' +
      '</article>';
  }

  function initCatalog() {
    var grid = document.querySelector('[data-catalog-grid]');
    if (!grid) return;

    var category = grid.getAttribute('data-category');
    var products = (window.ALINAS_BRAND_PRODUCTS || []).filter(function (p) {
      return p && p.category === category;
    });
    var emptyState = document.querySelector('[data-catalog-empty]');

    if (!products.length) {
      grid.innerHTML = '';
      if (emptyState) emptyState.hidden = false;
      return;
    }

    if (emptyState) emptyState.hidden = true;
    grid.innerHTML = products.map(renderProductCard).join('');
    initFadeIn();

    if (window.location.hash) {
      var id = decodeURIComponent(window.location.hash.slice(1));
      var target = document.getElementById(id);
      if (target) {
        setTimeout(function () {
          target.scrollIntoView({ behavior: 'smooth', block: 'start' });
          target.classList.add('catalog-model--highlight');
          setTimeout(function () { target.classList.remove('catalog-model--highlight'); }, 2000);
        }, 120);
      }
    }
  }

  function initAll() {
    initHomeContent();
    initMobileNav();
    initSearch();
    initProductGallery();
    initCatalog();
    initFadeIn();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initAll);
  } else {
    initAll();
  }
})();
