ФІКС ДЛЯ ALINA'S BRAND

Замініть файл у GitHub:
assets/js/site.js

Що виправлено:
1. Пошук тепер знаходить AB692, ab692, AB-692, 692, AB680/1, AB-680/1, 680/1.
2. Мобільна версія каталогу більше не рендерить всі фото одразу.
3. На мобільному показується тільки 6 товарів спочатку + кнопка Load more.
4. На мобільному для кожного товару в каталозі підтягується тільки 1 фото.
5. На десктопі показується максимум 3 фото на товар і товари вантажаться партіями.
6. Додано lazy loading/async decoding для фото.
7. Додано захист, щоб старі Safari не падали через IntersectionObserver.

Після commit у GitHub дочекайтесь Netlify deploy.
Потім на телефоні відкрийте сайт у приватному/інкогніто режимі або очистіть кеш Safari.

Якщо після deploy пошук все одно показує стару помилку, значить Safari/Netlify віддає старий кеш site.js.
Тоді в catalog-dresses.html, catalog-suits.html, catalog-jumpsuits.html замініть:
<script src="assets/js/site.js"></script>
на:
<script src="assets/js/site.js?v=4"></script>
