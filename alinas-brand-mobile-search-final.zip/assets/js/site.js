/* ============================================================
   ALINA'S BRAND — Site script
   Mobile menu, scroll reveals, catalog rendering, search.
   Fixed: mobile performance + article search normalization.
   ============================================================ */
(function () {
  'use strict';

  var WHATSAPP_URL = 'https://wa.me/380937709193';

  function escapeHtml(value) {
    return String(value == null ? '' : value).replace(/[&<>"']/g, function (char) {
      return {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#39;'
      }[char];
    });
  }

  function escapeAttr(value) {
    return escapeHtml(value);
  }

  function listText(value) {
    return Array.isArray(value) && value.length ? value.join(', ') : '—';
  }

  function cssUrl(value) {
    return 'url("' + String(value || '').replace(/\\/g, '\\\\').replace(/"/g, '\\"') + '")';
  }

  function isSmallScreen() {
    return !!(window.matchMedia && window.matchMedia('(max-width: 900px)').matches);
  }

  function normalizeArticle(value) {
    var text = String(value || '')
      .toUpperCase()
      .trim()
      .replace(/\s+/g, '')
      .replace(/[–—_]/g, '-')
      .replace(/^ART\.?/i, '')
      .replace(/^ARTICLE\.?/i, '')
      .replace(/\./g, '')
      .replace(/^AB-?/i, 'AB')
      .replace(/[^A-Z0-9/]/g, '');

    if (/^\d+(\/\d+)?$/.test(text)) {
      text = 'AB' + text;
    }

    return text;
  }

  function compactArticle(value) {
    return normalizeArticle(value).replace(/[^A-Z0-9]/g, '');
  }

  function articleToId(article) {
    return normalizeArticle(article)
      .toLowerCase()
      .replace(/\//g, '-')
      .replace(/[^a-z0-9-]/g, '');
  }

  function safeProductUrl(product) {
    if (product && product.pageUrl) return String(product.pageUrl);
    if (!product) return '';
    return 'catalog-' + encodeURIComponent(product.category || 'dresses') + '.html#' + articleToId(product.article);
  }

  function initFadeIn(root) {
    var scope = root || document;
    var items = Array.prototype.slice.call(scope.querySelectorAll('.fade-in'));
    if (!items.length) return;

    if (!('IntersectionObserver' in window)) {
      items.forEach(function (el) { el.classList.add('visible'); });
      return;
    }

    var obs = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          obs.unobserve(entry.target);
        }
      });
    }, { threshold: 0.08, rootMargin: '120px 0px' });

    items.forEach(function (el) { obs.observe(el); });
  }

  function initMobileNav() {
    var hamburger = document.querySelector('.hamburger');
    var mobileNav = document.querySelector('.mobile-nav');

    if (!hamburger || !mobileNav) return;

    hamburger.addEventListener('click', function () {
      mobileNav.classList.toggle('active');
      document.body.classList.toggle('nav-open');
    });

    mobileNav.querySelectorAll('a').forEach(function (link) {
      link.addEventListener('click', function () {
        mobileNav.classList.remove('active');
        document.body.classList.remove('nav-open');
      });
    });
  }

  function initHomeContent() {
    var home = window.ALINAS_BRAND_HOME;
    if (!home) return;

    var hero = home.hero || {};
    var heroBg = document.querySelector('[data-home-hero-image]');

    if (heroBg && hero.image) {
      heroBg.style.backgroundImage = cssUrl(hero.image);
      heroBg.style.setProperty('--hero-image-desktop', cssUrl(hero.image));
    }

    if (heroBg && hero.mobileImage) {
      heroBg.style.setProperty('--hero-image-mobile', cssUrl(hero.mobileImage));
    }

    if (heroBg && hero.imagePosition) {
      heroBg.style.backgroundPosition = hero.imagePosition;
    }

    var heroOvertitle = document.querySelector('[data-home-hero-overtitle]');
    var heroTitle = document.querySelector('[data-home-hero-title]');
    var heroSubtitle = document.querySelector('[data-home-hero-subtitle]');
    var heroButton = document.querySelector('[data-home-hero-button]');
    var heroKicker = document.querySelector('[data-home-hero-kicker]');

    if (heroOvertitle && hero.overtitle) heroOvertitle.textContent = hero.overtitle;
    if (heroTitle && hero.title) heroTitle.textContent = hero.title;
    if (heroSubtitle && hero.subtitle) heroSubtitle.textContent = hero.subtitle;
    if (heroButton) {
      if (hero.buttonText) heroButton.textContent = hero.buttonText;
      if (hero.buttonUrl) heroButton.setAttribute('href', hero.buttonUrl);
    }
    if (heroKicker && hero.kicker) heroKicker.textContent = hero.kicker;

    var categories = home.categories || {};
    Object.keys(categories).forEach(function (key) {
      var data = categories[key] || {};
      var card = document.querySelector('[data-home-category="' + key + '"]');
      if (!card) return;

      var image = card.querySelector('[data-home-category-image]');
      var title = card.querySelector('[data-home-category-title]');
      var subtitle = card.querySelector('[data-home-category-subtitle]');

      if (data.url) card.setAttribute('href', data.url);
      if (image && data.image) image.setAttribute('src', data.image);
      if (image && data.title) image.setAttribute('alt', data.title);
      if (title && data.title) title.textContent = data.title;
      if (subtitle && data.subtitle) subtitle.textContent = data.subtitle;
    });
  }

  function initProductGallery() {
    document.querySelectorAll('[data-product-gallery]').forEach(function (gallery) {
      var mainImage = gallery.querySelector('[data-product-main-image]');
      var thumbs = Array.prototype.slice.call(gallery.querySelectorAll('[data-product-thumb]'));

      if (!mainImage || !thumbs.length) return;

      thumbs.forEach(function (button) {
        button.addEventListener('click', function () {
          var nextImage = button.getAttribute('data-image');
          var nextAlt = button.getAttribute('data-alt') || mainImage.alt;

          if (!nextImage) return;

          mainImage.src = nextImage;
          mainImage.alt = nextAlt;

          thumbs.forEach(function (item) { item.classList.remove('is-active'); });
          button.classList.add('is-active');
        });
      });
    });
  }

  function findProductByArticle(raw) {
    var normalized = normalizeArticle(raw);
    var compact = compactArticle(raw);
    var products = window.ALINAS_BRAND_PRODUCTS || [];

    if (!normalized || !/\d/.test(normalized)) return null;

    return products.find(function (product) {
      return normalizeArticle(product.article) === normalized || compactArticle(product.article) === compact;
    }) || null;
  }

  function initSearch() {
    var toggle = document.querySelector('.search-toggle');
    var panel = document.querySelector('.search-panel');

    if (!toggle || !panel) return;

    var input = panel.querySelector('.search-input');
    var feedback = panel.querySelector('.search-feedback');
    var closeBtn = panel.querySelector('.search-close');

    if (!input) return;

    function setFeedback(message) {
      if (feedback) feedback.textContent = message || '';
    }

    function openPanel() {
      panel.classList.add('is-open');
      toggle.setAttribute('aria-expanded', 'true');
      setTimeout(function () { input.focus(); }, 50);
    }

    function closePanel() {
      panel.classList.remove('is-open');
      toggle.setAttribute('aria-expanded', 'false');
      setFeedback('');
      input.value = '';
    }

    function runSearch() {
      var raw = (input.value || '').trim();

      if (!raw) {
        setFeedback('Please enter an article number, for example AB692.');
        return;
      }

      if (!/\d/.test(raw)) {
        setFeedback('Article format is AB692, AB-692 or 692.');
        return;
      }

      var match = findProductByArticle(raw);

      if (!match) {
        setFeedback('No product found for "' + raw + '".');
        return;
      }

      setFeedback('Opening Art. ' + match.article + '...');
      window.location.href = safeProductUrl(match);
    }

    toggle.addEventListener('click', function (event) {
      event.preventDefault();
      if (panel.classList.contains('is-open')) closePanel();
      else openPanel();
    });

    if (closeBtn) closeBtn.addEventListener('click', closePanel);

    document.addEventListener('keydown', function (event) {
      if (event.key === 'Escape' && panel.classList.contains('is-open')) closePanel();
    });

    panel.addEventListener('submit', function (event) {
      event.preventDefault();
      runSearch();
    });
  }

  function injectCatalogPerformanceStyles() {
    if (document.getElementById('catalog-performance-fix-styles')) return;

    var style = document.createElement('style');
    style.id = 'catalog-performance-fix-styles';
    style.textContent = [
      '.catalog-load-more-wrap{display:flex;justify-content:center;margin-top:44px}',
      '.catalog-load-more{appearance:none;border:1px solid var(--color-text,#1f1f1f);background:transparent;color:var(--color-text,#1f1f1f);padding:14px 34px;font:inherit;font-size:.72rem;font-weight:500;letter-spacing:.18em;text-transform:uppercase;cursor:pointer;transition:opacity .2s ease,background .2s ease,color .2s ease}',
      '.catalog-load-more:hover{background:var(--color-text,#1f1f1f);color:#fff}',
      '.catalog-model--highlight{outline:1px solid var(--color-text,#1f1f1f);outline-offset:10px}',
      '@media(max-width:900px){.catalog-load-more{width:100%;max-width:320px}.catalog-model__gallery .catalog-model__frame:nth-child(n+2){display:none!important}}'
    ].join('\n');
    document.head.appendChild(style);
  }

  function renderCatalogProduct(product, index) {
    var article = product.article || '';
    var productUrl = safeProductUrl(product);
    var safeUrl = escapeAttr(productUrl);
    var safeName = escapeHtml(product.name || ('Art. ' + article));
    var safeArticle = escapeHtml(article);
    var safeTagline = escapeHtml(product.tagline || '');
    var safeDescription = escapeHtml(product.description || '');
    var safeColors = escapeHtml(listText(product.colors));
    var safeSizes = escapeHtml(listText(product.sizes));
    var safeAvailability = escapeHtml(product.availability || '');
    var productId = escapeAttr(articleToId(article));
    var imageLimit = isSmallScreen() ? 1 : 3;
    var galleryImages = (product.images || []).filter(Boolean).slice(0, imageLimit);

    if (!galleryImages.length) {
      galleryImages = [''];
    }

    var galleryHtml = galleryImages.map(function (src, imageIndex) {
      var loading = index < 2 ? 'eager' : 'lazy';
      var image = src
        ? '<img src="' + escapeAttr(src) + '" alt="' + escapeAttr((product.name || article) + ' image ' + (imageIndex + 1)) + '" loading="' + loading + '" decoding="async">'
        : '<span class="catalog-model__image-placeholder"></span>';

      return '<a class="catalog-model__frame" href="' + safeUrl + '" aria-label="View Art. ' + safeArticle + '">' + image + '</a>';
    }).join('');

    var whatsappMessage = encodeURIComponent('Hello, I am interested in Art. ' + article);

    return [
      '<article class="catalog-model fade-in" id="' + productId + '" data-article="' + escapeAttr(normalizeArticle(article)) + '">',
        '<div class="catalog-model__gallery">',
          galleryHtml,
        '</div>',
        '<div class="catalog-model__caption">',
          '<div class="catalog-model__article">Art. ' + safeArticle + '</div>',
          safeTagline ? '<div class="catalog-model__tagline">' + safeTagline + '</div>' : '',
          safeDescription ? '<p class="catalog-model__description">' + safeDescription + '</p>' : '',
          '<div class="catalog-model__meta">Available colors: ' + safeColors + '</div>',
          '<div class="catalog-model__meta">Available sizes: ' + safeSizes + '</div>',
          safeAvailability ? '<div class="catalog-model__meta">' + safeAvailability + '</div>' : '',
          '<a href="' + safeUrl + '" class="catalog-model__cta">View product</a>',
          '<a href="' + WHATSAPP_URL + '?text=' + whatsappMessage + '" target="_blank" rel="noopener" class="catalog-model__cta" style="margin-left:18px">WhatsApp</a>',
        '</div>',
      '</article>'
    ].join('');
  }

  function scrollToProductFromHash(renderUntilIndex) {
    if (!window.location.hash) return;

    var id = decodeURIComponent(window.location.hash.slice(1));
    if (!id) return;

    if (typeof renderUntilIndex === 'function') renderUntilIndex(id);

    var target = document.getElementById(id);
    if (!target) return;

    setTimeout(function () {
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      target.classList.add('catalog-model--highlight');
      setTimeout(function () { target.classList.remove('catalog-model--highlight'); }, 2200);
    }, 100);
  }

  function initCatalog() {
    var grid = document.querySelector('[data-catalog-grid]');
    if (!grid) return;

    injectCatalogPerformanceStyles();

    var category = grid.getAttribute('data-category');
    var products = (window.ALINAS_BRAND_PRODUCTS || []).filter(function (product) {
      return product.category === category;
    });
    var emptyState = document.querySelector('[data-catalog-empty]');

    if (!products.length) {
      grid.innerHTML = '';
      if (emptyState) emptyState.hidden = false;
      return;
    }

    if (emptyState) emptyState.hidden = true;

    var batchSize = isSmallScreen() ? 6 : 9;
    var renderedCount = 0;
    var buttonWrap = document.createElement('div');
    var button = document.createElement('button');

    buttonWrap.className = 'catalog-load-more-wrap';
    button.type = 'button';
    button.className = 'catalog-load-more';
    button.textContent = 'Load more';
    buttonWrap.appendChild(button);

    grid.innerHTML = '';

    if (grid.parentNode) {
      grid.parentNode.insertBefore(buttonWrap, grid.nextSibling);
    }

    function updateButton() {
      if (renderedCount >= products.length) {
        buttonWrap.hidden = true;
      } else {
        buttonWrap.hidden = false;
        button.textContent = 'Load more';
      }
    }

    function renderNextBatch(minCount) {
      var targetCount = typeof minCount === 'number'
        ? Math.min(products.length, Math.max(minCount, renderedCount + batchSize))
        : Math.min(products.length, renderedCount + batchSize);

      var html = '';
      for (var i = renderedCount; i < targetCount; i += 1) {
        html += renderCatalogProduct(products[i], i);
      }

      if (html) {
        grid.insertAdjacentHTML('beforeend', html);
        initFadeIn(grid);
      }

      renderedCount = targetCount;
      updateButton();
    }

    function renderUntilHashId(id) {
      var index = products.findIndex(function (product) {
        return articleToId(product.article) === id;
      });

      if (index >= 0 && index >= renderedCount) {
        renderNextBatch(index + 1);
      }
    }

    button.addEventListener('click', function () {
      renderNextBatch();
    });

    renderNextBatch();
    scrollToProductFromHash(renderUntilHashId);
  }

  function initAll() {
    initHomeContent();
    initMobileNav();
    initSearch();
    initProductGallery();
    initCatalog();
    initFadeIn();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initAll);
  } else {
    initAll();
  }
}());
