(function () {
  'use strict';

  var WA_NUMBER = '380673236531';
  var MOBILE_QUERY = '(max-width: 900px)';
  var renderedCatalogMode = null;

  function qs(selector, root) {
    return (root || document).querySelector(selector);
  }

  function qsa(selector, root) {
    return Array.prototype.slice.call((root || document).querySelectorAll(selector));
  }

  function safeText(value) {
    return value == null ? '' : String(value);
  }

  function escapeHtml(value) {
    return safeText(value).replace(/[&<>"']/g, function (char) {
      return {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#39;'
      }[char];
    });
  }

  function escapeAttr(value) {
    return escapeHtml(value).replace(/`/g, '&#96;');
  }

  function normalizeSpaces(value) {
    return safeText(value).replace(/\s+/g, ' ').trim();
  }

  function latinize(value) {
    // Allows accidental Cyrillic letters in article search: АВ692 -> AB692
    return safeText(value)
      .replace(/[Аа]/g, 'A')
      .replace(/[Вв]/g, 'B')
      .replace(/[Сс]/g, 'C')
      .replace(/[Ее]/g, 'E')
      .replace(/[Нн]/g, 'H')
      .replace(/[Кк]/g, 'K')
      .replace(/[Мм]/g, 'M')
      .replace(/[Оо]/g, 'O')
      .replace(/[Рр]/g, 'P')
      .replace(/[Тт]/g, 'T')
      .replace(/[Хх]/g, 'X');
  }

  function normalizeArticle(value) {
    var input = latinize(value).toUpperCase().trim();

    // Keep letters and numbers only: AB-680/1, AB 680.1, AB680_1 -> AB6801
    var compact = input.replace(/[^A-Z0-9]/g, '');

    // If customer types only digits, search as AB + digits.
    if (/^\d+$/.test(compact)) {
      compact = 'AB' + compact;
    }

    return compact;
  }

  function normalizeArticleDisplay(value) {
    var input = latinize(value).toUpperCase().trim();
    var cleaned = input.replace(/[^A-Z0-9\/\-]/g, '');

    if (/^\d/.test(cleaned)) {
      cleaned = 'AB' + cleaned;
    }

    return cleaned;
  }

  function slugifyArticle(value) {
    return safeText(value)
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '');
  }

  function cleanAssetPath(path) {
    if (!path) return '';

    var src = safeText(path).trim();
    if (!src) return '';
    if (/^(https?:)?\/\//i.test(src) || src.charAt(0) === '/') return src;

    return '/' + src.replace(/^\/+/, '');
  }

  function normalizeInternalUrl(url) {
    var href = safeText(url).trim();
    if (!href) return '';

    if (href.indexOf('/product/') === 0 && href.indexOf('.') === -1 && href.slice(-1) !== '/') {
      return href + '/';
    }

    return href;
  }

  function productUrl(product) {
    if (!product) return '';

    var existing = normalizeInternalUrl(product.pageUrl || product.url || product.href || '');
    if (existing) return existing;

    var slug = slugifyArticle(product.article || product.id || product.title || '');
    return slug ? '/product/' + slug + '/' : '';
  }

  function categoryUrl(category, hash) {
    var cat = safeText(category || 'dresses').toLowerCase();
    return '/catalog-' + cat + '.html' + (hash ? '#' + hash : '');
  }

  function getProducts() {
    return Array.isArray(window.ALINAS_BRAND_PRODUCTS) ? window.ALINAS_BRAND_PRODUCTS : [];
  }

  function getCategories() {
    return window.ALINAS_BRAND_CATEGORIES || {};
  }

  function getIsMobile() {
    return window.matchMedia && window.matchMedia(MOBILE_QUERY).matches;
  }

  function findProductByQuery(query) {
    var products = getProducts();
    var normalizedQuery = normalizeArticle(query);
    var displayQuery = normalizeArticleDisplay(query);

    if (!normalizedQuery) return null;

    return products.find(function (product) {
      var article = product.article || product.id || '';
      var articleNormalized = normalizeArticle(article);
      var articleSlug = slugifyArticle(article);
      var querySlug = slugifyArticle(displayQuery);

      return articleNormalized === normalizedQuery ||
        articleSlug === querySlug ||
        articleSlug === slugifyArticle(query) ||
        normalizeArticle(product.title || '') === normalizedQuery;
    }) || null;
  }

  function setupSearch() {
    var searchToggles = qsa('.search-toggle');
    var searchPanel = qs('.search-panel');
    var searchInput = qs('.search-input');
    var searchFeedback = qs('.search-feedback');

    if (!searchInput) return;

    function setFeedback(message) {
      if (searchFeedback) {
        searchFeedback.textContent = message || '';
      }
    }

    function openSearch() {
      if (searchPanel) searchPanel.classList.add('is-open');
      searchToggles.forEach(function (toggle) {
        toggle.setAttribute('aria-expanded', 'true');
      });
      window.setTimeout(function () {
        searchInput.focus();
      }, 30);
    }

    function closeSearch() {
      if (searchPanel) searchPanel.classList.remove('is-open');
      searchToggles.forEach(function (toggle) {
        toggle.setAttribute('aria-expanded', 'false');
      });
    }

    searchToggles.forEach(function (toggle) {
      toggle.addEventListener('click', function () {
        if (searchPanel && searchPanel.classList.contains('is-open')) {
          closeSearch();
        } else {
          openSearch();
        }
      });
    });

    var form = searchInput.closest('form') || searchInput.parentElement;
    if (form) {
      form.addEventListener('submit', function (event) {
        event.preventDefault();
        runSearch(searchInput.value);
      });
    }

    searchInput.addEventListener('keydown', function (event) {
      if (event.key === 'Enter') {
        event.preventDefault();
        runSearch(searchInput.value);
      }

      if (event.key === 'Escape') {
        closeSearch();
      }
    });

    function runSearch(rawValue) {
      var value = normalizeSpaces(rawValue);
      var products = getProducts();

      setFeedback('');

      if (!value) {
        setFeedback('Введіть артикул, наприклад AB692.');
        return;
      }

      if (!products.length) {
        setFeedback('Каталог ще завантажується. Спробуйте ще раз через секунду.');
        return;
      }

      var match = findProductByQuery(value);

      if (!match) {
        setFeedback('Не знайдено. Спробуйте формат AB692, AB-692, 692 або AB680/1.');
        return;
      }

      var href = productUrl(match);
      if (!href) {
        href = categoryUrl(match.category || 'dresses', slugifyArticle(match.article || value));
      }

      window.location.href = href;
    }
  }

  function setupMobileNav() {
    var hamburger = qs('.hamburger');
    var mobileNav = qs('.mobile-nav');

    if (!hamburger || !mobileNav) return;

    hamburger.addEventListener('click', function () {
      var isOpen = mobileNav.classList.toggle('is-open');
      hamburger.classList.toggle('is-active', isOpen);
      hamburger.setAttribute('aria-expanded', String(isOpen));
      document.body.classList.toggle('nav-open', isOpen);
    });

    qsa('a', mobileNav).forEach(function (link) {
      link.addEventListener('click', function () {
        mobileNav.classList.remove('is-open');
        hamburger.classList.remove('is-active');
        hamburger.setAttribute('aria-expanded', 'false');
        document.body.classList.remove('nav-open');
      });
    });
  }

  function setupRevealAnimations() {
    var elements = qsa('.fade-in, .stagger-item');
    if (!elements.length) return;

    if (!('IntersectionObserver' in window)) {
      elements.forEach(function (element) {
        element.classList.add('is-visible');
      });
      return;
    }

    var observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });

    elements.forEach(function (element) {
      observer.observe(element);
    });
  }

  function renderList(values, emptyText) {
    var items = Array.isArray(values) ? values.filter(Boolean) : [];
    if (!items.length) return escapeHtml(emptyText || '—');

    return items.map(function (item) {
      return '<span>' + escapeHtml(item) + '</span>';
    }).join('');
  }

  function catalogImageLimit() {
    // Biggest speed win: mobile catalog loads one image per product, desktop loads three.
    // Full galleries stay available on each product page.
    return getIsMobile() ? 1 : 3;
  }

  function renderCatalogCard(product, index, imageLimit) {
    var article = product.article || product.id || '';
    var articleSlug = slugifyArticle(article || product.title || ('product-' + index));
    var title = normalizeSpaces(product.title || product.name || '');
    var tagline = normalizeSpaces(product.tagline || product.subtitle || '');
    var description = normalizeSpaces(product.description || product.fabric || '');
    var colors = product.colors || product.availableColors || [];
    var sizes = product.sizes || product.availableSizes || [];
    var availability = normalizeSpaces(product.availability || product.status || '');
    var href = productUrl(product);
    var images = Array.isArray(product.images) ? product.images.filter(Boolean).slice(0, imageLimit) : [];
    var articleLabel = article ? 'Art. ' + article : title;

    var gallery = images.map(function (image, imageIndex) {
      var src = cleanAssetPath(image.src || image.url || image.path || image);
      if (!src) return '';

      var alt = image.alt || (articleLabel + (title ? ' — ' + title : ''));
      var loading = index === 0 && imageIndex === 0 ? 'eager' : 'lazy';
      var priority = index === 0 && imageIndex === 0 ? ' fetchpriority="high"' : '';
      var img = '<img src="' + escapeAttr(src) + '" alt="' + escapeAttr(alt) + '" loading="' + loading + '" decoding="async"' + priority + '>';

      if (href) {
        return '<a class="catalog-model__frame" href="' + escapeAttr(href) + '" aria-label="View ' + escapeAttr(articleLabel) + '">' + img + '</a>';
      }

      return '<div class="catalog-model__frame">' + img + '</div>';
    }).join('');

    if (!gallery) {
      gallery = '<div class="catalog-model__frame catalog-model__frame--empty"><span>' + escapeHtml(articleLabel) + '</span></div>';
    }

    var meta = '';
    if ((Array.isArray(colors) && colors.length) || (Array.isArray(sizes) && sizes.length) || availability) {
      meta = '<div class="catalog-model__meta">' +
        '<div><strong>Colors:</strong> ' + renderList(colors, 'on request') + '</div>' +
        '<div><strong>Sizes:</strong> ' + renderList(sizes, 'on request') + '</div>' +
        (availability ? '<div>' + escapeHtml(availability) + '</div>' : '') +
        '</div>';
    }

    var cta = href
      ? '<a class="catalog-model__cta" href="' + escapeAttr(href) + '">View product</a>'
      : '<a class="catalog-model__cta" href="https://wa.me/' + WA_NUMBER + '?text=' + encodeURIComponent('Hello! I am interested in ' + articleLabel) + '">Enquire on WhatsApp</a>';

    return '<article class="catalog-model fade-in" id="' + escapeAttr(articleSlug) + '" data-article="' + escapeAttr(normalizeArticle(article)) + '">' +
      '<div class="catalog-model__gallery">' + gallery + '</div>' +
      '<div class="catalog-model__caption">' +
        (article ? '<div class="catalog-model__article">' + escapeHtml(articleLabel) + '</div>' : '') +
        (title ? '<h2>' + escapeHtml(title) + '</h2>' : '') +
        (tagline ? '<div class="catalog-model__tagline">' + escapeHtml(tagline) + '</div>' : '') +
        (description ? '<p class="catalog-model__description">' + escapeHtml(description) + '</p>' : '') +
        meta +
        cta +
      '</div>' +
    '</article>';
  }

  function renderCatalog() {
    var grid = qs('[data-catalog-grid]');
    if (!grid) return;

    var requestedCategory = safeText(grid.getAttribute('data-category') || '').toLowerCase();
    var products = getProducts();
    var imageLimit = catalogImageLimit();
    var mode = getIsMobile() ? 'mobile' : 'desktop';

    var items = products.filter(function (product) {
      if (!requestedCategory) return true;
      return safeText(product.category).toLowerCase() === requestedCategory;
    });

    grid.innerHTML = items.map(function (product, index) {
      return renderCatalogCard(product, index, imageLimit);
    }).join('');

    var emptyState = qs('.catalog-empty');
    if (emptyState) {
      emptyState.hidden = items.length > 0;
    }

    renderedCatalogMode = mode;
    setupRevealAnimations();
    scrollToHashAfterCatalogRender();
  }

  function scrollToHashAfterCatalogRender() {
    if (!window.location.hash) return;

    var rawHash = decodeURIComponent(window.location.hash.slice(1));
    var hash = slugifyArticle(rawHash) || rawHash;
    var selector = '#' + (window.CSS && CSS.escape ? CSS.escape(hash) : hash.replace(/[^a-zA-Z0-9_-]/g, '\\$&'));
    var target = qs(selector);

    if (!target) {
      var normalized = normalizeArticle(rawHash);
      target = qs('[data-article="' + normalized + '"]');
    }

    if (target) {
      window.setTimeout(function () {
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 80);
    }
  }

  function setupCatalogResizeOptimization() {
    if (!qs('[data-catalog-grid]') || !window.matchMedia) return;

    var media = window.matchMedia(MOBILE_QUERY);
    var rerender = function () {
      var newMode = media.matches ? 'mobile' : 'desktop';
      if (renderedCatalogMode && renderedCatalogMode !== newMode) {
        renderCatalog();
      }
    };

    if (media.addEventListener) {
      media.addEventListener('change', rerender);
    } else if (media.addListener) {
      media.addListener(rerender);
    }
  }

  function setupHomeContent() {
    var home = window.ALINAS_BRAND_HOME;
    if (!home) return;

    var binders = qsa('[data-home-field]');
    binders.forEach(function (element) {
      var key = element.getAttribute('data-home-field');
      if (!key || home[key] == null) return;
      element.textContent = home[key];
    });

    var listBinders = qsa('[data-home-list]');
    listBinders.forEach(function (element) {
      var key = element.getAttribute('data-home-list');
      var values = Array.isArray(home[key]) ? home[key] : [];
      if (!values.length) return;
      element.innerHTML = values.map(function (value) {
        return '<li>' + escapeHtml(value) + '</li>';
      }).join('');
    });
  }

  function setupProductGallery() {
    var galleries = qsa('[data-product-gallery]');
    if (!galleries.length) return;

    galleries.forEach(function (gallery) {
      var mainImage = qs('[data-product-main]', gallery);
      var buttons = qsa('[data-product-thumb]', gallery);

      if (mainImage) {
        mainImage.setAttribute('loading', 'eager');
        mainImage.setAttribute('decoding', 'async');
      }

      buttons.forEach(function (button, index) {
        var thumbImg = qs('img', button);
        if (thumbImg) {
          thumbImg.setAttribute('loading', index < 3 ? 'eager' : 'lazy');
          thumbImg.setAttribute('decoding', 'async');
        }

        button.addEventListener('click', function () {
          var src = button.getAttribute('data-product-thumb');
          var alt = button.getAttribute('data-product-alt') || '';
          if (!src || !mainImage) return;

          mainImage.src = src;
          mainImage.alt = alt;
          buttons.forEach(function (item) {
            item.classList.remove('is-active');
          });
          button.classList.add('is-active');
        });
      });
    });
  }

  function boot() {
    setupMobileNav();
    setupSearch();
    setupHomeContent();
    renderCatalog();
    setupCatalogResizeOptimization();
    setupProductGallery();
    setupRevealAnimations();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
